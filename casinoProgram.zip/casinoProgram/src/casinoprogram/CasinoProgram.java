package casinoprogram;

public class CasinoProgram {

    public static void main(String[] args) {
        loginScreen login = new loginScreen();
        login.setVisible(true);
        login.setResizable(false);
    }
    
}
