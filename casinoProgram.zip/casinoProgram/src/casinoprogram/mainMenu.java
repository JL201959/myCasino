package casinoprogram;

import java.awt.Color;
import java.awt.Font;

public class mainMenu extends javax.swing.JFrame {

    public static int chips = 500;
    public String name = loginScreen.username;

    public mainMenu() {
        initComponents();
        nameDisplay.setText("Name: " + name);
        
        this.getContentPane().setBackground(Color.GRAY);
        
        blackjackButton.setBackground(Color.WHITE);
        slotsButton.setBackground(Color.WHITE);
        HOLButton.setBackground(Color.WHITE);
        purchaseButton.setBackground(Color.WHITE);

        nameDisplay.setForeground(Color.WHITE);
        chipDisplay.setForeground(Color.WHITE);
        
        nameDisplay.setFont(new Font("Serif", Font.PLAIN, 20));
        chipDisplay.setFont(new Font("Serif", Font.PLAIN, 20));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        nameDisplay = new javax.swing.JLabel();
        chipDisplay = new javax.swing.JLabel();
        purchaseButton = new javax.swing.JButton();
        blackjackButton = new javax.swing.JButton();
        HOLButton = new javax.swing.JButton();
        slotsButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        nameDisplay.setText("Name:");

        chipDisplay.setText("Chips: 500");
        chipDisplay.setText("Chips: " + chips);

        purchaseButton.setText("Purchase Chips");
        purchaseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purchaseButtonActionPerformed(evt);
            }
        });

        blackjackButton.setText("Blackjack");
        blackjackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                blackjackButtonActionPerformed(evt);
            }
        });

        HOLButton.setText("Higher or Lower");
        HOLButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HOLButtonActionPerformed(evt);
            }
        });

        slotsButton.setText("Slots");
        slotsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                slotsButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(chipDisplay, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(nameDisplay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 275, Short.MAX_VALUE)
                        .addComponent(purchaseButton))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(176, 176, 176)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(HOLButton, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(blackjackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(slotsButton, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nameDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(purchaseButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(chipDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(blackjackButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(HOLButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(slotsButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void purchaseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purchaseButtonActionPerformed
        storeScreen store = new storeScreen();
        store.setVisible(true);
        store.setResizable(false);
    }//GEN-LAST:event_purchaseButtonActionPerformed

    private void blackjackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_blackjackButtonActionPerformed
        this.setVisible(false);
        blackjackGame blackJack = new blackjackGame();
        blackJack.setVisible(true);
        blackJack.setResizable(false);
    }//GEN-LAST:event_blackjackButtonActionPerformed

    private void HOLButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HOLButtonActionPerformed
        this.setVisible(false);
        HOLGame HOL = new HOLGame();
        HOL.setVisible(true);
        HOL.setResizable(false);
    }//GEN-LAST:event_HOLButtonActionPerformed

    private void slotsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_slotsButtonActionPerformed
        this.setVisible(false);
        slots slots = new slots();
        slots.setVisible(true);
        slots.setResizable(false);
    }//GEN-LAST:event_slotsButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(mainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(mainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(mainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(mainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new mainMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton HOLButton;
    private javax.swing.JButton blackjackButton;
    public static javax.swing.JLabel chipDisplay;
    private javax.swing.JLabel nameDisplay;
    private javax.swing.JButton purchaseButton;
    private javax.swing.JButton slotsButton;
    // End of variables declaration//GEN-END:variables
}
