package casinoprogram;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.util.Random;
import javax.swing.ImageIcon;

public class slots extends javax.swing.JFrame {

    public static Random random = new Random();

    public static int userBet;
    public static int betReturn;

    public static int slot1Num;
    public static int slot2Num;
    public static int slot3Num;

    public static ImageIcon seven = new ImageIcon("7.png");
    public static ImageIcon gem = new ImageIcon("gem.png");
    public static ImageIcon clover = new ImageIcon("clover.png");
    public static ImageIcon cherry = new ImageIcon("cherry.png");
    public static ImageIcon orange = new ImageIcon("orange.png");
    public static ImageIcon melon = new ImageIcon("melon.png");
    public static ImageIcon bell = new ImageIcon("bell.png");
    public static ImageIcon lemon = new ImageIcon("lemon.png");

    public slots() {
        initComponents();
        
        this.getContentPane().setBackground(Color.GRAY);
        
        slot1.setBackground(Color.WHITE);
        slot2.setBackground(Color.WHITE);
        slot3.setBackground(Color.WHITE);

        bet1.setBackground(Color.WHITE);
        bet2.setBackground(Color.WHITE);
        bet3.setBackground(Color.WHITE);
        
        spinButton.setBackground(Color.WHITE);
        scoresButton.setBackground(Color.WHITE);
        exitButton.setBackground(Color.WHITE);
        
        spinButton.setEnabled(false);

        chipDisplay.setText("Chips: " + mainMenu.chips);
        
        chipDisplay.setForeground(Color.WHITE);
        chipDisplay.setFont(new Font("Serif", Font.PLAIN, 15));
        
        betReturnDisplay.setForeground(Color.WHITE);
        betReturnDisplay.setFont(new Font("Serif", Font.PLAIN, 20));
    }

    public static void scores() {

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        if (slot1Num == 0) {
            betReturn = betReturn + (userBet * 2);
        }

        if (slot2Num == 10) {
            betReturn = betReturn + (userBet * 2);
        }

        if (slot3Num == 0) {
            betReturn = betReturn + (userBet * 2);
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        if (slot1Num == 1) {
            betReturn = betReturn + 500;
        }

        if (slot2Num == 1) {
            betReturn = betReturn + 500;
        }

        if (slot3Num == 1) {
            betReturn = betReturn + 500;
        }

        if (slot1Num == 1 && slot2Num == 1 && slot3Num == 1) {
            betReturn = betReturn + 500;
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
        if (slot1Num != 0 && slot2Num != 0 && slot3Num != 0 || slot1Num != 1 && slot2Num != 1 && slot3Num != 1) {
            if (slot1Num == slot2Num && slot1Num == slot3Num) {
                betReturn = betReturn + (userBet * 2);
            }

            if (slot1Num == slot2Num || slot1Num == slot3Num || slot2Num == slot3Num) {
                betReturn = betReturn + userBet + (userBet / 2);
            }
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        mainMenu.chips = mainMenu.chips + betReturn;
        mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
        chipDisplay.setText("Chips: " + mainMenu.chips);

        bet1.setEnabled(true);
        bet2.setEnabled(true);
        bet3.setEnabled(true);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        slot1 = new javax.swing.JButton();
        slot2 = new javax.swing.JButton();
        slot3 = new javax.swing.JButton();
        bet1 = new javax.swing.JButton();
        bet2 = new javax.swing.JButton();
        bet3 = new javax.swing.JButton();
        spinButton = new javax.swing.JButton();
        chipDisplay = new javax.swing.JLabel();
        exitButton = new javax.swing.JButton();
        scoresButton = new javax.swing.JButton();
        betReturnDisplay = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        bet1.setText("100");
        bet1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bet1ActionPerformed(evt);
            }
        });

        bet2.setText("500");
        bet2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bet2ActionPerformed(evt);
            }
        });

        bet3.setText("1000");
        bet3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bet3ActionPerformed(evt);
            }
        });

        spinButton.setText("Spin!");
        spinButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                spinButtonActionPerformed(evt);
            }
        });

        chipDisplay.setText("Chips:");

        exitButton.setText("Exit");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });

        scoresButton.setText("Scoring Info");
        scoresButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                scoresButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(slot1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(slot2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(scoresButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(slot3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(spinButton))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(bet3, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(bet2, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(chipDisplay, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(bet1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)))
                                .addGap(69, 69, 69)
                                .addComponent(betReturnDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(chipDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(exitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(scoresButton, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(40, 40, 40)
                                        .addComponent(slot1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(slot2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(slot3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addComponent(spinButton, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addComponent(bet1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(bet2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(betReturnDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)))
                .addComponent(bet3, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void bet1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bet1ActionPerformed
        userBet = 100;

        if (mainMenu.chips >= userBet) {

            mainMenu.chips = mainMenu.chips - userBet;
            chipDisplay.setText("Chips: " + mainMenu.chips);
            mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);

            bet1.setEnabled(false);
            bet2.setEnabled(false);
            bet3.setEnabled(false);

            spinButton.setEnabled(true);
            betReturnDisplay.setText("");
        }
    }//GEN-LAST:event_bet1ActionPerformed

    private void bet2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bet2ActionPerformed
        userBet = 500;

        if (mainMenu.chips >= userBet) {

            mainMenu.chips = mainMenu.chips - userBet;
            chipDisplay.setText("Chips: " + mainMenu.chips);
            mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);

            bet1.setEnabled(false);
            bet2.setEnabled(false);
            bet3.setEnabled(false);

            spinButton.setEnabled(true);
            betReturnDisplay.setText("");
        }
    }//GEN-LAST:event_bet2ActionPerformed

    private void bet3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bet3ActionPerformed
        userBet = 1000;

        if (mainMenu.chips >= userBet) {

            mainMenu.chips = mainMenu.chips - userBet;
            chipDisplay.setText("Chips: " + mainMenu.chips);
            mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);

            bet1.setEnabled(false);
            bet2.setEnabled(false);
            bet3.setEnabled(false);

            spinButton.setEnabled(true);
            betReturnDisplay.setText("");
        }
    }//GEN-LAST:event_bet3ActionPerformed

    private void spinButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_spinButtonActionPerformed
        slot1Num = random.nextInt(8);
        slot2Num = random.nextInt(8);
        slot3Num = random.nextInt(8);

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        if (slot1Num == 0) {
            slot1.setIcon(new ImageIcon(seven.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot1Num == 1) {
            slot1.setIcon(new ImageIcon(gem.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot1Num == 2) {
            slot1.setIcon(new ImageIcon(clover.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot1Num == 3) {
            slot1.setIcon(new ImageIcon(cherry.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot1Num == 4) {
            slot1.setIcon(new ImageIcon(orange.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot1Num == 5) {
            slot1.setIcon(new ImageIcon(melon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot1Num == 6) {
            slot1.setIcon(new ImageIcon(bell.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot1Num == 7) {
            slot1.setIcon(new ImageIcon(lemon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        if (slot2Num == 0) {
            slot2.setIcon(new ImageIcon(seven.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot2Num == 1) {
            slot2.setIcon(new ImageIcon(gem.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot2Num == 2) {
            slot2.setIcon(new ImageIcon(clover.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot2Num == 3) {
            slot2.setIcon(new ImageIcon(cherry.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot2Num == 4) {
            slot2.setIcon(new ImageIcon(orange.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot2Num == 5) {
            slot2.setIcon(new ImageIcon(melon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot2Num == 6) {
            slot2.setIcon(new ImageIcon(bell.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot2Num == 7) {
            slot2.setIcon(new ImageIcon(lemon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        if (slot3Num == 0) {
            slot3.setIcon(new ImageIcon(seven.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot3Num == 1) {
            slot3.setIcon(new ImageIcon(gem.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot3Num == 2) {
            slot3.setIcon(new ImageIcon(clover.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot3Num == 3) {
            slot3.setIcon(new ImageIcon(cherry.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot3Num == 4) {
            slot3.setIcon(new ImageIcon(orange.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot3Num == 5) {
            slot3.setIcon(new ImageIcon(melon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot3Num == 6) {
            slot3.setIcon(new ImageIcon(bell.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        if (slot3Num == 7) {
            slot3.setIcon(new ImageIcon(lemon.getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT)));
        }

        spinButton.setEnabled(false);

        scores();

        betReturnDisplay.setText("You won " + betReturn + " chips!");

    }//GEN-LAST:event_spinButtonActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        dispose();
        mainMenu menu = new mainMenu();
        menu.setVisible(true);
        menu.setResizable(false);

        mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void scoresButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_scoresButtonActionPerformed
        slotScores score = new slotScores();
        score.setVisible(true);
        score.setResizable(false);
    }//GEN-LAST:event_scoresButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(slots.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(slots.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(slots.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(slots.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new slots().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JButton bet1;
    public static javax.swing.JButton bet2;
    public static javax.swing.JButton bet3;
    private javax.swing.JLabel betReturnDisplay;
    public static javax.swing.JLabel chipDisplay;
    private javax.swing.JButton exitButton;
    private javax.swing.JButton scoresButton;
    private javax.swing.JButton slot1;
    private javax.swing.JButton slot2;
    private javax.swing.JButton slot3;
    private javax.swing.JButton spinButton;
    // End of variables declaration//GEN-END:variables
}
