package casinoprogram;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.util.Random;
import javax.swing.ImageIcon;

public class blackjackGame extends javax.swing.JFrame {

    public static String[] cards = new String[]{"A", "2", "3", "4", "5", "6", "7", "8", "9", "T", "J", "Q", "K"};
    public static String[] suits = new String[]{"H.png", "D.png", "S.png", "C.png"};

    public static Random random = new Random();

    public static int cardpick = random.nextInt(13);
    public static int suitpick = random.nextInt(4);

    public static String cardFull = cards[cardpick].concat(suits[suitpick]);

    public static int cardpicknew;
    public static int suitpicknew;

    public static int dealerCount = 0;
    public static int userCount = 0;
    public static int aceCount = 0;

    public static boolean win = false;

    public static int twisted = 0;
    public static int betReturn = 0;

    public static ImageIcon cardBack = new ImageIcon("BackOfCard.png");
    public static ImageIcon cardImage = new ImageIcon(cardFull);

    public blackjackGame() {
        initComponents();

        chipDisplay.setText("Chips: " + mainMenu.chips);

        startButton.setVisible(true);
        replayButton.setVisible(false);

        userCard1.setVisible(false);
        userCard2.setVisible(false);
        userCard3.setVisible(false);
        userCard4.setVisible(false);
        userCard5.setVisible(false);

        dealerCard1.setVisible(false);
        dealerCard2.setVisible(false);
        dealerCard3.setVisible(false);

        stickButton.setVisible(false);
        twistButton.setVisible(false);
        
        this.getContentPane().setBackground(Color.GRAY);
        
        startButton.setBackground(Color.WHITE);
        twistButton.setBackground(Color.WHITE);
        stickButton.setBackground(Color.WHITE);
        replayButton.setBackground(Color.WHITE);
        
        userCounter.setForeground(Color.WHITE);
        compCounter.setForeground(Color.WHITE);
        chipDisplay.setForeground(Color.WHITE);
        
        userCounter.setFont(new Font("Serif", Font.PLAIN, 20));
        compCounter.setFont(new Font("Serif", Font.PLAIN, 20));
        chipDisplay.setFont(new Font("Serif", Font.PLAIN, 20));
    }

    public static void counter1() {
        if (cardpick == 0) {
            userCount = userCount + 11;
            aceCount = aceCount + 1;
        }

        if (cardpick == 9 || cardpick == 10 || cardpick == 11 || cardpick == 12) {
            userCount = userCount + 10;
        }
        
        else {
            userCount = userCount + (cardpick + 1);
        }
        
        userCounter.setText("Player: " + userCount);
    }

    public static void counter2() {
        if (cardpicknew == 0) {
            userCount = userCount + 11;
            aceCount = aceCount + 1;
        }

        if (cardpicknew == 9 || cardpicknew == 10 || cardpicknew == 11 || cardpicknew == 12) {
            userCount = userCount + 10;
        }
        
        else {
            userCount = userCount + (cardpicknew + 1);
        }
        
        userCounter.setText("Player: " + userCount);
    }

    public static void dealerCounter() {
        if ((cardpicknew + 1) <= 10) {
            dealerCount = dealerCount + (cardpicknew + 1);
        }

        if ((cardpicknew + 1) > 10) {
            dealerCount = dealerCount + 10;
        }
    }

    public static void shuffle() {
        cardpicknew = random.nextInt(13);
        suitpicknew = random.nextInt(4);
        cardFull = cards[cardpicknew].concat(suits[suitpicknew]);
    }

    public static void dealUser() {
        userCard1.setVisible(true);
        userCard2.setVisible(true);

        userCard1.setIcon(new ImageIcon(cardImage.getImage().getScaledInstance(110, 150, Image.SCALE_DEFAULT)));
        counter1();

        cardpicknew = random.nextInt(13);
        suitpicknew = random.nextInt(4);
        cardFull = cards[cardpicknew].concat(suits[suitpicknew]);

        cardImage = new ImageIcon(cardFull);

        userCard2.setIcon(new ImageIcon(cardImage.getImage().getScaledInstance(110, 150, Image.SCALE_DEFAULT)));

        counter2();

        cardpick = cardpicknew;

        dealComputer();
    }

    public static void dealComputer() {
        dealerCard1.setVisible(true);
        dealerCard2.setVisible(true);

        cardpicknew = random.nextInt(13);
        suitpicknew = random.nextInt(4);
        cardFull = cards[cardpicknew].concat(suits[suitpicknew]);

        cardImage = new ImageIcon(cardFull);

        dealerCard1.setIcon(new ImageIcon(cardImage.getImage().getScaledInstance(110, 150, Image.SCALE_DEFAULT)));
        dealerCounter();

        cardpick = cardpicknew;

        cardpicknew = random.nextInt(13);
        suitpicknew = random.nextInt(4);
        cardFull = cards[cardpicknew].concat(suits[suitpicknew]);

        dealerCard2.setIcon(new ImageIcon(cardBack.getImage().getScaledInstance(110, 150, Image.SCALE_DEFAULT)));
        dealerCounter();

        cardpick = cardpicknew;

        stickButton.setVisible(true);
        twistButton.setVisible(true);
    }

    public static void dealerSelect() {
        if (dealerCount < 17) {
            dealerCard3.setVisible(true);

            cardpicknew = random.nextInt(13);
            suitpicknew = random.nextInt(4);
            cardFull = cards[cardpicknew].concat(suits[suitpicknew]);

            dealerCard3.setIcon(new ImageIcon(cardBack.getImage().getScaledInstance(110, 150, Image.SCALE_DEFAULT)));
            dealerCounter();

            cardpick = cardpicknew;

            while (dealerCount < 17) {

                cardpicknew = random.nextInt(13);
                suitpicknew = random.nextInt(4);
                cardFull = cards[cardpicknew].concat(suits[suitpicknew]);

                dealerCounter();

                cardpick = cardpicknew;
            }
            
            stick();

        } else {
            stick();
        }
    }

    public static void stick() {
        if (userCount > 21) {
            win = false;
        }

        if (dealerCount > 21) {
            win = true;
        }

        if (userCount <= 21 && userCount > dealerCount) {
            win = true;
        }

        if (dealerCount <= 21 && dealerCount >= userCount) {
            win = false;
        }
        
        points();
    }

    public static void twist1() {
        
        userCard3.setVisible(true);
        
        cardpicknew = random.nextInt(13);
        suitpicknew = random.nextInt(4);
        cardFull = cards[cardpicknew].concat(suits[suitpicknew]);
        
        cardImage = new ImageIcon(cardFull);
        
        userCard3.setIcon(new ImageIcon(cardImage.getImage().getScaledInstance(110, 150, Image.SCALE_DEFAULT)));
        counter2();

        cardpick = cardpicknew;
        
        if(userCount > 21 && aceCount == 0) {
            twistButton.setEnabled(false);
            stick();
        }
        
        if(userCount > 21 && aceCount > 0) {
            userCount = userCount - (10 * aceCount);
        }
    }
    
    public static void twist2() {
        
        userCard4.setVisible(true);
        
        cardpicknew = random.nextInt(13);
        suitpicknew = random.nextInt(4);
        cardFull = cards[cardpicknew].concat(suits[suitpicknew]);
        
        cardImage = new ImageIcon(cardFull);
        
        userCard4.setIcon(new ImageIcon(cardImage.getImage().getScaledInstance(110, 150, Image.SCALE_DEFAULT)));
        counter2();

        cardpick = cardpicknew;
        
        if(userCount > 21 && aceCount == 0) {
            twistButton.setEnabled(false);
            stick();
        }
        
        if(userCount > 21 && aceCount > 0) {
            userCount = userCount - (10 * aceCount);
        }
    }
    
    public static void twist3() {
        
        userCard5.setVisible(true);
        
        cardpicknew = random.nextInt(13);
        suitpicknew = random.nextInt(4);
        cardFull = cards[cardpicknew].concat(suits[suitpicknew]);
        
        cardImage = new ImageIcon(cardFull);
        
        userCard5.setIcon(new ImageIcon(cardImage.getImage().getScaledInstance(110, 150, Image.SCALE_DEFAULT)));
        counter2();

        cardpick = cardpicknew;
        
        if(userCount > 21 && aceCount == 0) {
            twistButton.setEnabled(false);
            stick();
        }
        
        if(userCount > 21 && aceCount > 0) {
            userCount = userCount - (10 * aceCount);
        }
    }
    
    public static void points() {
        if(win == true) {
            compCounter.setText("Computer: " + dealerCount);
            winDisplay.setText("You Win!");
            betReturn = blackjackBets.userBet + (blackjackBets.userBet / 2);
            mainMenu.chips = mainMenu.chips + betReturn;
            
            mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
            chipDisplay.setText("Chips: " + mainMenu.chips);
            
            replayButton.setVisible(true);
        }
        
        if(win == false) {
            compCounter.setText("Computer: " + dealerCount);
            winDisplay.setText("You lose!");
            replayButton.setVisible(true);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        chipDisplay = new javax.swing.JLabel();
        startButton = new javax.swing.JButton();
        userCard1 = new javax.swing.JButton();
        userCard2 = new javax.swing.JButton();
        userCard3 = new javax.swing.JButton();
        userCard4 = new javax.swing.JButton();
        userCard5 = new javax.swing.JButton();
        dealerCard1 = new javax.swing.JButton();
        dealerCard2 = new javax.swing.JButton();
        dealerCard3 = new javax.swing.JButton();
        userCounter = new javax.swing.JLabel();
        stickButton = new javax.swing.JButton();
        twistButton = new javax.swing.JButton();
        compCounter = new javax.swing.JLabel();
        winDisplay = new javax.swing.JLabel();
        replayButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        chipDisplay.setText("Chips: ");

        startButton.setText("Start");
        startButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                startButtonActionPerformed(evt);
            }
        });

        userCard1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userCard1ActionPerformed(evt);
            }
        });

        userCard2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userCard2ActionPerformed(evt);
            }
        });

        userCard3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userCard3ActionPerformed(evt);
            }
        });

        userCard4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userCard4ActionPerformed(evt);
            }
        });

        userCard5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userCard5ActionPerformed(evt);
            }
        });

        userCounter.setText("Player: ");

        stickButton.setText("Stick");
        stickButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stickButtonActionPerformed(evt);
            }
        });

        twistButton.setText("Twist");
        twistButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                twistButtonActionPerformed(evt);
            }
        });

        compCounter.setText("Computer: ?");

        replayButton.setText("Replay");
        replayButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                replayButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(chipDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userCounter, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(compCounter, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(winDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userCard1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(userCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(userCard3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(userCard4, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(userCard5, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(51, 51, 51)
                                .addComponent(stickButton, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(28, 28, 28)
                                .addComponent(twistButton, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(78, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(dealerCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dealerCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dealerCard3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(startButton, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(replayButton, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(chipDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(userCounter, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(compCounter, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(winDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(dealerCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dealerCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dealerCard3, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(stickButton, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(twistButton, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(startButton, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(replayButton, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 72, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(userCard1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userCard2, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userCard3, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userCard4, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userCard5, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void startButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_startButtonActionPerformed
        blackjackBets bets = new blackjackBets();
        bets.setVisible(true);
        bets.setResizable(false);
    }//GEN-LAST:event_startButtonActionPerformed

    private void userCard1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userCard1ActionPerformed

    }//GEN-LAST:event_userCard1ActionPerformed

    private void userCard2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userCard2ActionPerformed

    }//GEN-LAST:event_userCard2ActionPerformed

    private void userCard3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userCard3ActionPerformed

    }//GEN-LAST:event_userCard3ActionPerformed

    private void userCard4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userCard4ActionPerformed

    }//GEN-LAST:event_userCard4ActionPerformed

    private void userCard5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userCard5ActionPerformed

    }//GEN-LAST:event_userCard5ActionPerformed

    private void stickButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stickButtonActionPerformed
        twistButton.setEnabled(false);

        dealerSelect();
    }//GEN-LAST:event_stickButtonActionPerformed

    private void twistButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_twistButtonActionPerformed
        twisted = twisted + 1;
        
        if(twisted == 1) {
            twist1();
        }
        
        if(twisted == 2) {
            twist2();
        }
        
        if(twisted == 3) {
            twist3();
        }
    }//GEN-LAST:event_twistButtonActionPerformed

    private void replayButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_replayButtonActionPerformed
        dispose();
        
        twisted = 0;
        betReturn = 0;
        userCount = 0;
        dealerCount = 0;
        win = false;
        
        blackjackGame blackJack = new blackjackGame();
        blackJack.setVisible(true);
        blackJack.setResizable(false);
        
        
    }//GEN-LAST:event_replayButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(blackjackGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(blackjackGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(blackjackGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(blackjackGame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new blackjackGame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JLabel chipDisplay;
    public static javax.swing.JLabel compCounter;
    public static javax.swing.JButton dealerCard1;
    public static javax.swing.JButton dealerCard2;
    public static javax.swing.JButton dealerCard3;
    public static javax.swing.JButton replayButton;
    public static javax.swing.JButton startButton;
    public static javax.swing.JButton stickButton;
    public static javax.swing.JButton twistButton;
    public static javax.swing.JButton userCard1;
    public static javax.swing.JButton userCard2;
    public static javax.swing.JButton userCard3;
    public static javax.swing.JButton userCard4;
    public static javax.swing.JButton userCard5;
    public static javax.swing.JLabel userCounter;
    public static javax.swing.JLabel winDisplay;
    // End of variables declaration//GEN-END:variables
}
