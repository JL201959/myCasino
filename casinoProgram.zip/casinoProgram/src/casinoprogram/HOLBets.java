package casinoprogram;

import static casinoprogram.HOLGame.cardDisplay;
import static casinoprogram.HOLGame.cardFull;
import static casinoprogram.HOLGame.cardpick;
import static casinoprogram.HOLGame.cardpicknew;
import static casinoprogram.HOLGame.cards;
import static casinoprogram.HOLGame.random;
import static casinoprogram.HOLGame.suits;
import java.awt.Color;
import java.awt.Font;
import static java.lang.Integer.parseInt;
import javax.swing.ImageIcon;

public class HOLBets extends javax.swing.JFrame {

    public static boolean min = false;
    public static boolean max = false;
    public static boolean custom = false;
    public static boolean started = false;
    public static boolean higher = false;

    public int userBet;
    public int betReturn;

    public HOLBets() {
        initComponents();
        betInput.setEnabled(false);
        chipDisplay.setText("Chips: " + mainMenu.chips);
        
        this.getContentPane().setBackground(Color.GRAY);
        
        minButton.setBackground(Color.WHITE);
        customButton.setBackground(Color.WHITE);
        maxButton.setBackground(Color.WHITE);
        cancelButton.setBackground(Color.WHITE);
        confirmButton.setBackground(Color.WHITE);
        
        label1.setForeground(Color.WHITE);
        label2.setForeground(Color.WHITE);
        chipDisplay.setForeground(Color.WHITE);
        
        label1.setFont(new Font("Serif", Font.PLAIN, 15));
        label2.setFont(new Font("Serif", Font.PLAIN, 15));
        chipDisplay.setFont(new Font("Serif", Font.PLAIN, 15));
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        label1 = new javax.swing.JLabel();
        betInput = new javax.swing.JTextField();
        minButton = new javax.swing.JButton();
        maxButton = new javax.swing.JButton();
        customButton = new javax.swing.JButton();
        label2 = new javax.swing.JLabel();
        chipDisplay = new javax.swing.JLabel();
        cancelButton = new javax.swing.JButton();
        confirmButton = new javax.swing.JButton();
        ERROR = new javax.swing.JLabel();

        jLabel3.setText("jLabel3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        label1.setText("Please select your bets:");

        minButton.setText("Min");
        minButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minButtonActionPerformed(evt);
            }
        });

        maxButton.setText("Max");
        maxButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                maxButtonActionPerformed(evt);
            }
        });

        customButton.setText("Custom");
        customButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                customButtonActionPerformed(evt);
            }
        });

        label2.setText("Min: 10                        Max: 1000");

        chipDisplay.setText("Chips:");

        cancelButton.setText("Cancel");
        cancelButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancelButtonActionPerformed(evt);
            }
        });

        confirmButton.setText("Confirm");
        confirmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(chipDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(minButton, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(63, 63, 63)
                                .addComponent(customButton, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(57, 57, 57)
                                .addComponent(maxButton, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42)
                                .addComponent(label2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(116, 116, 116)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(betInput, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ERROR, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(33, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(55, 55, 55)
                .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(confirmButton, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(chipDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(minButton, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(customButton, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(maxButton, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ERROR, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(betInput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(confirmButton, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void minButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minButtonActionPerformed
        maxButton.setEnabled(false);
        customButton.setEnabled(false);
        min = true;
    }//GEN-LAST:event_minButtonActionPerformed

    private void customButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_customButtonActionPerformed
        maxButton.setEnabled(false);
        minButton.setEnabled(false);
        custom = true;
        betInput.setEnabled(true);
    }//GEN-LAST:event_customButtonActionPerformed

    private void maxButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_maxButtonActionPerformed
        minButton.setEnabled(false);
        customButton.setEnabled(false);
        max = true;
    }//GEN-LAST:event_maxButtonActionPerformed

    private void cancelButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancelButtonActionPerformed
        maxButton.setEnabled(true);
        minButton.setEnabled(true);
        customButton.setEnabled(true);

        betInput.setText("");
        betInput.setEnabled(false);

        max = false;
        min = false;
        custom = false;
    }//GEN-LAST:event_cancelButtonActionPerformed

    private void confirmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmButtonActionPerformed
        if (min == true) {
            userBet = 10;
            if (mainMenu.chips >= userBet) {
                mainMenu.chips = mainMenu.chips - userBet;
                chipDisplay.setText("Chips: " + mainMenu.chips);
                mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);

                HOLGame.cardpicknew = random.nextInt(12);
                HOLGame.suitpicknew = random.nextInt(3);
                cardFull = cards[HOLGame.cardpicknew].concat(suits[HOLGame.suitpicknew]);
                if (higher == true) {
                    if (cardpick == cardpicknew) {
                        betReturn = userBet;
                        mainMenu.chips = mainMenu.chips + betReturn;
                        chipDisplay.setText("Chips: " + mainMenu.chips);
                        mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                        HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                        cardpick = cardpicknew;
                        
                    }
                    if (cardpick > cardpicknew) {
                        cardpick = cardpicknew;
                    }
                    if (cardpick < cardpicknew) {
                        betReturn = userBet + (userBet / 2);
                        mainMenu.chips = mainMenu.chips + betReturn;
                        chipDisplay.setText("Chips: " + mainMenu.chips);
                        mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                        HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                        cardpick = cardpicknew;
                    }

                    ImageIcon cardfull = new ImageIcon(cardFull);
                    cardDisplay.setIcon(cardfull);
                }

                if (higher == false) {
                    if (cardpick == cardpicknew) {
                        betReturn = userBet;
                        mainMenu.chips = mainMenu.chips + betReturn;
                        chipDisplay.setText("Chips: " + mainMenu.chips);
                        mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                        HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                        cardpick = cardpicknew;
                        
                    }
                    if (cardpick > cardpicknew) {
                        cardpick = cardpicknew;
                        
                    }
                    if (cardpick < cardpicknew) {
                        betReturn = userBet + (userBet / 2);
                        mainMenu.chips = mainMenu.chips + betReturn;
                        chipDisplay.setText("Chips: " + mainMenu.chips);
                        mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                        HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                        HOLGame.cardpick = HOLGame.cardpicknew;
                        
                    }
                    
                    ImageIcon cardfull = new ImageIcon(cardFull);
                    cardDisplay.setIcon(cardfull);
                }
            }
        }

        if (custom == true) {
            if (parseInt(betInput.getText()) >= 10 && parseInt(betInput.getText()) <= 1000) {
                userBet = parseInt(betInput.getText());
                if (mainMenu.chips >= userBet) {
                    mainMenu.chips = mainMenu.chips - userBet;
                    chipDisplay.setText("Chips: " + mainMenu.chips);
                    mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                    HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);

                    HOLGame.cardpicknew = random.nextInt(12);
                    HOLGame.suitpicknew = random.nextInt(3);
                    cardFull = cards[HOLGame.cardpicknew].concat(suits[HOLGame.suitpicknew]);
                    if (higher == true) {
                        if (cardpick == cardpicknew) {
                            betReturn = userBet;
                            mainMenu.chips = mainMenu.chips + betReturn;
                            chipDisplay.setText("Chips: " + mainMenu.chips);
                            mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                            HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                        }
                        if (cardpick > cardpicknew) {
                            cardpick = cardpicknew;
                        }
                        if (cardpick < cardpicknew) {
                            betReturn = userBet * (userBet / 2);
                            mainMenu.chips = mainMenu.chips + betReturn;
                            chipDisplay.setText("Chips: " + mainMenu.chips);
                            mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                            HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                            cardpick = cardpicknew;
                        }

                        ImageIcon cardfull = new ImageIcon(cardFull);
                        cardDisplay.setIcon(cardfull);
                    }

                    if (higher == false) {
                        if (cardpick == cardpicknew) {
                            betReturn = userBet;
                            mainMenu.chips = mainMenu.chips + betReturn;
                            chipDisplay.setText("Chips: " + mainMenu.chips);
                            mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                            HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                        }
                        if (cardpick > cardpicknew) {
                            cardpick = cardpicknew;
                        }
                        if (cardpick < cardpicknew) {
                            betReturn = userBet * (userBet / 2);
                            mainMenu.chips = mainMenu.chips + betReturn;
                            chipDisplay.setText("Chips: " + mainMenu.chips);
                            mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                            HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                            HOLGame.cardpick = HOLGame.cardpicknew;
                            HOLGame.cardpick = HOLGame.cardpicknew;

                            ImageIcon cardfull = new ImageIcon(cardFull);
                            cardDisplay.setIcon(cardfull);
                        }
                    }
                }
            } else {
                ERROR.setText("Please enter a number (10 - 1000): ");
            }
        }

        if (max == true) {
            userBet = 1000;
            if (mainMenu.chips >= userBet) {
                mainMenu.chips = mainMenu.chips - userBet;
                chipDisplay.setText("Chips: " + mainMenu.chips);
                mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);

                HOLGame.cardpicknew = random.nextInt(12);
                HOLGame.suitpicknew = random.nextInt(3);
                cardFull = cards[HOLGame.cardpicknew].concat(suits[HOLGame.suitpicknew]);
                if (higher == true) {
                    if (cardpick == cardpicknew) {
                        betReturn = userBet;
                        mainMenu.chips = mainMenu.chips + betReturn;
                        chipDisplay.setText("Chips: " + mainMenu.chips);
                        mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                        HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                    }
                    if (cardpick > cardpicknew) {
                        cardpick = cardpicknew;
                    }
                    if (cardpick < cardpicknew) {
                        betReturn = userBet * (userBet / 2);
                        mainMenu.chips = mainMenu.chips + betReturn;
                        chipDisplay.setText("Chips: " + mainMenu.chips);
                        mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                        HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                        cardpick = cardpicknew;
                    }

                    ImageIcon cardfull = new ImageIcon(cardFull);
                    cardDisplay.setIcon(cardfull);
                }

                if (higher == false) {
                    if (cardpick == cardpicknew) {
                        betReturn = userBet;
                        mainMenu.chips = mainMenu.chips + betReturn;
                        chipDisplay.setText("Chips: " + mainMenu.chips);
                        mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                        HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                    }
                    if (cardpick > cardpicknew) {
                        cardpick = cardpicknew;
                    }
                    if (cardpick < cardpicknew) {
                        betReturn = userBet * (userBet / 2);
                        mainMenu.chips = mainMenu.chips + betReturn;
                        chipDisplay.setText("Chips: " + mainMenu.chips);
                        mainMenu.chipDisplay.setText("Chips: " + mainMenu.chips);
                        HOLGame.chipDisplay.setText("Chips: " + mainMenu.chips);
                        
                        HOLGame.cardpick = HOLGame.cardpicknew;
                        HOLGame.cardpick = HOLGame.cardpicknew;

                        ImageIcon cardfull = new ImageIcon(cardFull);
                        cardDisplay.setIcon(cardfull);
                    }
                }
            }
        }
        
        this.setVisible(false);

    }//GEN-LAST:event_confirmButtonActionPerformed

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HOLBets.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HOLBets.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HOLBets.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HOLBets.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HOLBets().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ERROR;
    private javax.swing.JTextField betInput;
    private javax.swing.JButton cancelButton;
    public static javax.swing.JLabel chipDisplay;
    public javax.swing.JButton confirmButton;
    private javax.swing.JButton customButton;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel label1;
    private javax.swing.JLabel label2;
    private javax.swing.JButton maxButton;
    private javax.swing.JButton minButton;
    // End of variables declaration//GEN-END:variables
}
